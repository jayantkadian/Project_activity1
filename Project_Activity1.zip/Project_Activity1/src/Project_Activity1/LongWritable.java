package Project_Activity1;

public class LongWritable {

	public int get() {
		// TODO Auto-generated method stub
		return 0;
	}

}
